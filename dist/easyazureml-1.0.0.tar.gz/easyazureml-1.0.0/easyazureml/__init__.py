def sampleFn():
  return "Hello World - Easy Azure ML"

  
