# easyazureml
Python Package to simplify the ML tasks to be done in Azure Machine Learning
